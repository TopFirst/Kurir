<?php

namespace App\Http\Controllers;

use App\Models\Seller;
use App\Models\Tblantar;
use App\Models\User;
use App\Models\Tbljemput;
use App\Models\Transaksi;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Facade\FlareClient\Http\Exceptions\NotFound;
use Yajra\DataTables\DataTables;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $kurirs=User::all();
        if(Auth::user()->hasRole('Kurir'))
        {
            // $userid=Auth::user()->id;
            // $id_baru=Str::of(date('y'))->append(date('m'))->append('-'.$userid)->append('-00001');
            // if(Tbljemput::where('user_id',$userid)->exists())
            // {
            //     $last_id=Tbljemput::select('id')
            //     ->whereMonth('created_at',date('m'))
            //     ->whereYear('created_at',date('Y'))
            //     ->where('user_id',$userid)
            //     ->orderByDesc('id')
            //     ->first()->id;
            //     $urutan=(int)Str::afterLast($last_id, '-');
            //     $urutanbaru = sprintf('%05d', $urutan+1);
            //     $id_baru=Str::of(date('y'))->append(date('m'))->append('-'.$userid)->append('-'.$urutanbaru);
            // }
            $id_baru=Str::of(date('y'))->append(date('m'))->append('-'. Auth::user()->id)->append('-'. $this->str_random());
            while(Tbljemput::where('id',$id_baru)->exists())
            {
                $id_baru=Str::of(date('y'))->append(date('m'))->append('-'. $this->str_random());
            }
            $sellers=Seller::all();
            return view('transaksi/create',compact('kurirs','sellers'))
            ->with('title', 'Kurir')
            ->with('id_baru', $id_baru);
        }
        elseif(Auth::user()->hasRole('Admin'))
        {
            // $jemputs = Tbljemput::latest()->take(5)->get();

            $kurirs=User::whereHas("roles", function($q){ $q->where("name", "Kurir"); })->get();
            $total_kurir=$kurirs->count();
            $kurirs=$kurirs->sortByDesc(function($query){
                return $query->jemputan->count();
            });
            $sellers=Seller::all()->sortByDesc(function($query){
                return $query->jemputan->count();
            })->take(4);

            $total_jemput=Tbljemput::all()->count();
            $total_antar=Tblantar::all()->count();
            
            $total_seller=Seller::all()->count();
            return view('db',compact('kurirs','sellers'))
            ->with('total_jemput', $total_jemput)
            ->with('total_antar', $total_antar)
            ->with('total_kurir', $total_kurir)
            ->with('total_seller', $total_seller)
            ->with('title', 'Home');
        }
        else{
            return redirect()->route('web.index');
        }
    }
    /**
     * Generate a "random" alpha-numeric string.
     *
     * Should not be considered sufficient for cryptography, etc.
     *
     * @param  int  $length
     * @return string
     */
    function str_random($length = 4)
    {
        $pool = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';

        return substr(str_shuffle(str_repeat($pool, $length)), 0, $length);
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function cekresi()
    {
        if(request('txtcari'))
        {
            if(Tbljemput::where('id',request('txtcari'))->exists())
            {
                $dat=Tbljemput::find(request('txtcari'));
                return view('transaksi/cekresi',compact('dat'));
            }
            else
                return redirect('/');
        }
        return redirect('/');
    }
    /**
     * Ambil data json untuk data yang belum diantar.
     *
     * @return \Illuminate\Http\Response
     */
    public function json()
    {
        // return Datatables::of(Tbljemput::all())->make(true);
        $data=Tbljemput::doesntHave('antar')
        // ->orWhereHas("antar", function($q){ $q->where("status_id", 3); })
        ->get();

        // $totalbeluminput=Tbljemput::doesntHave('antar')->count();
        // $totalcancel=Tbljemput::WhereHas("antar", function($q){ $q->where("status_id", 3); })->count();

        $totaljemput=Tbljemput::all()->count();
        $totalantar=Tblantar::all()->count();


            return Datatables::of($data)
                    ->addIndexColumn()

                    ->editColumn('id', function($row){
                        $btn = '<a href="'.route('transaksi.show',$row->id).'">'.$row->id.'</a>';
                           return $btn;
                    })
                    ->addColumn('kurirjemput', function($row){
                            return $row->kurir->name;
                    })
                    ->addColumn('status', function($row){
                        $stt='<span class="badge badge-warning">Belum Input</span>';
                        if(isset($row->antar))
                        {
                            if($row->antar->status->id==3)
                                $stt='<span class="badge badge-danger">'.$row->antar->status->name.'</span>';
                            else
                                $stt='<span class="badge badge-info">'.$row->antar->status->name.'</span>';
                        }
                            return $stt;
                            // return $row->antar->status->name??'-';
                    })

                    ->rawColumns(['id','status'])
                    ->with('totaljemput',$totaljemput)
                    ->with('totalantar',$totalantar)
                    ->make(true);
    }
    /**
     * Ambil data json untuk data yang cancel.
     *
     * @return \Illuminate\Http\Response
     */
    public function json_cancel()
    {
        $data=Tbljemput::WhereHas("antar", function($q){ $q->where("status_id", 3); })->get();
            return Datatables::of($data)
                    ->addIndexColumn()

                    ->editColumn('id', function($row){
                        $btn = '<a href="'.route('transaksi.show',$row->id).'">'.$row->id.'</a>';
                           return $btn;
                    })
                    ->addColumn('kurirjemput', function($row){
                            return $row->kurir->name;
                    })
                    ->addColumn('status', function($row){
                        $stt='<span class="badge badge-warning">Belum Input</span>';
                        if(isset($row->antar))
                        {
                            if($row->antar->status->id==3)
                                $stt='<span class="badge badge-danger">'.$row->antar->status->name.'</span>';
                            else
                                $stt='<span class="badge badge-info">'.$row->antar->status->name.'</span>';
                        }
                            return $stt;
                            // return $row->antar->status->name??'-';
                    })

                    ->rawColumns(['id','status'])
                    ->make(true);
    }
}
